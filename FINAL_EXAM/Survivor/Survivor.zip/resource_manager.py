import pygame
import os
import sys

# 메모리 캐싱을 위한 딕셔너리 (한 번 로드한 리소스는 여기서 꺼내 씀)
_images = {}
_sounds = {}
_fonts = {}

# PyInstaller가 패킹할 때 임시 경로를 찾아주는 함수
def resource_path(relative_path):
    """ 실행 파일 내의 리소스 경로를 반환합니다. """
    try:
        # PyInstaller로 패킹된 환경
        base_path = sys._MEIPASS
    except Exception:
        # 일반 파이썬 실행 환경
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

# 기존의 get_image 함수가 있다면 이렇게 수정하세요
def get_image(path):
    real_path = resource_path(path) # 경로를 변환
    return pygame.image.load(real_path).convert_alpha()

def get_sound(path):
    """
    효과음(SFX)을 로드합니다.
    """
    global _sounds
    if path not in _sounds:
        full_path = get_resource_path(path)
        try:
            _sounds[path] = pygame.mixer.Sound(full_path)
        except pygame.error as e:
            print(f"사운드를 찾을 수 없습니다: {full_path}")
            # 에러가 나면 빈 사운드 객체를 만들 수는 없으므로 None 반환
            _sounds[path] = None
            
    return _sounds[path]

def get_font(path, size):
    """
    외부 폰트 파일(.ttf)을 로드합니다. 크기별로 따로 캐싱합니다.
    """
    global _fonts
    key = f"{path}_{size}"
    
    if key not in _fonts:
        full_path = get_resource_path(path)
        try:
            _fonts[key] = pygame.font.Font(full_path, size)
        except pygame.error as e:
            print(f"폰트를 찾을 수 없습니다: {full_path}. 기본 폰트로 대체합니다.")
            _fonts[key] = pygame.font.SysFont(None, size)
            
    return _fonts[key]

def play_bgm(path, volume=0.5):
    """
    배경음악(BGM)을 재생합니다. BGM은 스트리밍 방식이므로 캐싱하지 않습니다.
    """
    full_path = get_resource_path(path)
    try:
        pygame.mixer.music.load(full_path)
        pygame.mixer.music.set_volume(volume)
        pygame.mixer.music.play(-1) # -1: 무한 반복
    except pygame.error as e:
        print(f"BGM을 찾을 수 없거나 재생할 수 없습니다: {full_path}")


# ========================================================
# 👇 기존 play_bgm 함수 아래에 이 코드들을 추가해 주세요 👇
# ========================================================

# 사운드 겹침 방지용 쿨타임 딕셔너리
_sound_cooldowns = {}

def play_sound(path, volume=0.5, cooldown_ms=50):
    """
    효과음(SFX)을 안전하게 재생합니다.
    동일한 소리가 동시에 수십 번 재생되어 스피커가 찢어지거나 프레임이 드랍되는 것을 막아줍니다.
    """
    global _sound_cooldowns
    current_time = pygame.time.get_ticks()
    
    # 1. 쿨타임 체크 (짧은 시간 내에 같은 소리 중복 재생 방지)
    if path in _sound_cooldowns:
        if current_time - _sound_cooldowns[path] < cooldown_ms:
            return # 쿨타임이 안 지났으면 무시
            
    # 2. 사운드 캐싱 및 가져오기 (기존에 만드신 get_sound 함수 활용)
    snd = get_sound(path)
    
    if snd is not None:
        # 3. 빈 오디오 채널을 찾아 재생 (채널이 꽉 찼으면 무시하여 게임 튕김 방지)
        channel = pygame.mixer.find_channel()
        if channel:
            snd.set_volume(volume)
            channel.play(snd)
            _sound_cooldowns[path] = current_time

def load_sprite_sheet(path, frame_width, frame_height, columns, rows):
    """
    스프라이트 시트를 불러와서 프레임별로 자른 2차원 리스트를 반환합니다.
    반환 형태: frames[row][column]
    """
    sheet = get_image(path, alpha=True)
    frames = []
    
    for row in range(rows):
        row_frames = []
        for col in range(columns):
            x = col * frame_width
            y = row * frame_height
            # 💡 [핵심] subsurface로 원본 이미지의 특정 영역만 잘라냅니다.
            # 잘라낸 조각도 메모리를 공유하므로 매우 가볍습니다!
            frame = sheet.subsurface(pygame.Rect(x, y, frame_width, frame_height))
            row_frames.append(frame)
        frames.append(row_frames)
        
    return frames